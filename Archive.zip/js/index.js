$(document).ready(function(){
    $("section").scroll(function(){
        $("heroImg").fadeIn();
        $("MySkills").fadeIn("slow");
        $("SelectWork").fadeIn(3000);
    });
  });